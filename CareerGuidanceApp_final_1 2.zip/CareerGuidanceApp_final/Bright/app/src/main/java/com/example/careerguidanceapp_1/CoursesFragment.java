package com.example.careerguidanceapp_1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class CoursesFragment extends Fragment {



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_courses, container, false);
        CardView engCard = view.findViewById(R.id.eng);
        CardView medCard = view.findViewById(R.id.med);
        CardView artCard = view.findViewById(R.id.art1);
        CardView inspirationCard = view.findViewById(R.id.inspiration);

        // Set OnClickListener for engCard
        engCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to engineering link
                redirectToLink("https://www.shiksha.com/engineering-chp");
            }
        });

        // Set OnClickListener for medCard
        medCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to medical link
                redirectToLink("https://www.shiksha.com/medicine-health-sciences/pharmacy-course-chp");
            }
        });

        // Set OnClickListener for artCard
        artCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to art link
                redirectToLink("https://www.indeed.com/career-advice/finding-a-job/careers-in-the-art-field");
            }
        });

        // Set OnClickListener for inspirationCard
        inspirationCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to inspiration link
                redirectToLink("https://www.shiksha.com/commerce-chp");
            }
        });
        return view; }

    // Method to redirect to a link
    private void redirectToLink(String link) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
        startActivity(intent);
    }
        // Inflate the layout for this fragment

    }
