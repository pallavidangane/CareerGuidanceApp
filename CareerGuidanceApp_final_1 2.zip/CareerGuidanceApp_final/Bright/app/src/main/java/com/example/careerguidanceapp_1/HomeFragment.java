package com.example.careerguidanceapp_1;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {

    CardView Category;
    CardView PersonalityTest;
    CardView Job;
    CardView Inspiration;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        Category = view.findViewById(R.id.category);
        PersonalityTest = view.findViewById(R.id.personalitytest1);
        Job = view.findViewById(R.id.job);
        Inspiration = view.findViewById(R.id.inspiration);

        Category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Category.class);
                startActivity(intent);
            }
        });

        PersonalityTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), PersonalityTest.class);
                startActivity(intent);
            }
        });

        Job.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), job.class);
                startActivity(intent);
            }
        });

        Inspiration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Inspiration.class);
                startActivity(intent);
            }
        });

        return view;
    }
}
