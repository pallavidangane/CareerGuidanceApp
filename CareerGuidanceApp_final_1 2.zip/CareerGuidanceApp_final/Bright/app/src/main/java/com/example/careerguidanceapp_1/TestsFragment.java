package com.example.careerguidanceapp_1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;


public class TestsFragment extends Fragment {
    Button b1,b2,b3,b4;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tests, container, false);
        // Find buttons by their IDs
       b1=view.findViewById(R.id.startTestButton1);
       b2=view.findViewById(R.id.startTestButton2);
       b3=view.findViewById(R.id.startTestButton3);
       b4=view.findViewById(R.id.startTestButton4);
       b1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               // Define the action when button 1 is clicked
// For example, you can start a new activity
               String url = "https://www.indiabix.com/online-test/aptitude-test/";
               Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
               startActivity(intent);
           }
       });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Define the action when button 1 is clicked
// For example, you can start a new activity
                String url = "https://www.indiabix.com/online-test/aptitude-test";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Define the action when button 1 is clicked
// For example, you can start a new activity
                String url = "https://www.selfstudys.com/mcq/cuet/online/mock-test/fine-arts";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
// Define the action when button 4 is clicked
                String url = "https://www.selfstudys.com/mcq/cuet/online/mock-test/commerce-mock-test";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);

            }
        });

        // Inflate the layout for this fragment
        return view;
    }
}