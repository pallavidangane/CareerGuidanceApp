package com.example.careerguidanceapp_1;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;


import com.example.careerguidanceapp_1.databinding.ActivityInspirationBinding;

public class Inspiration extends AppCompatActivity {
    ActivityInspirationBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInspirationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.inter.setOnClickListener(v -> startActivity(new Intent(Inspiration.this,InterviewActivity.class)));
        binding.Btech.setOnClickListener(v -> startActivity(new Intent(Inspiration.this,BtechActivity.class)));
        binding.lor.setOnClickListener(v -> startActivity(new Intent(Inspiration.this,lorActivity.class)));
        binding.pharm.setOnClickListener(v -> startActivity(new Intent(Inspiration.this,PharmActivity.class)));
        binding.plife.setOnClickListener(v -> startActivity(new Intent(Inspiration.this,plife.class)));



    }
}