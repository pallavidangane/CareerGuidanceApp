package com.example.careerguidanceapp_1;


import android.os.Bundle;

import android.view.MenuItem;

import android.widget.Toast;

import androidx.annotation.NonNull;

import androidx.appcompat.app.ActionBarDrawerToggle;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.Toolbar;

import androidx.core.view.GravityCompat;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.fragment.app.Fragment;

import androidx.fragment.app.FragmentManager;

import androidx.fragment.app.FragmentTransaction;

import com.example.careerguidanceapp_1.databinding.ActivityHomePageBinding;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

public class HomePage extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ActivityHomePageBinding binding;


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        binding = ActivityHomePageBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        Toolbar toolbar = binding.toolbar;

        setSupportActionBar(toolbar);

        DrawerLayout drawerLayout = binding.drawerLayout;

        NavigationView navigationView = binding.navDraw;



        // Set up the navigation icon click listener

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(

                this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav

        );

        drawerLayout.addDrawerListener(toggle);

        toggle.syncState();

        if (savedInstanceState == null) {

            getSupportFragmentManager().beginTransaction().replace(R.id.frame_layout, new HomeFragment()).commit();

            navigationView.setCheckedItem(R.id.nav_home);

        }

        binding.bottomNavigation.setBackground(null);

        binding.bottomNavigation.setOnItemSelectedListener(item -> {

            if (item.getItemId() == R.id.home) {

                replaceFragment(new HomeFragment());

            } else if (item.getItemId() == R.id.courses) {

                replaceFragment(new CoursesFragment());

            } else if (item.getItemId() == R.id.tests) {

                replaceFragment(new TestsFragment());

            }

            return true;

        });

        binding.navDraw.setNavigationItemSelectedListener(item -> {
            if (item.getItemId()== R.id.nav_home) {

            replaceFragment(new HomeFragment());

        } else if (item.getItemId() == R.id.nav_settings) {

            replaceFragment(new SettingsFragment());

        } else if (item.getItemId()==R.id.nav_about){
                replaceFragment(new AboutFragment());
            }


        return true;
        });

    }

    private void replaceFragment(Fragment fragment) {

        FragmentManager fragmentManager = getSupportFragmentManager();

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        fragmentTransaction.replace(R.id.frame_layout, fragment);

        fragmentTransaction.commit();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, fragment)
                .commit();

    }

    @Override

    public boolean onNavigationItemSelected(@NonNull MenuItem item) {


return true;
    }

    @Override

    public void onBackPressed() {

        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {

            binding.drawerLayout.closeDrawer(GravityCompat.START);

        } else {

            super.onBackPressed();

        }

    }

}
