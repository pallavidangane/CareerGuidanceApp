package com.example.careerguidanceapp_1;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;

import com.example.careerguidanceapp_1.databinding.ActivityPersonalityTestBinding;

public class PersonalityTest extends AppCompatActivity {
    ActivityPersonalityTestBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityPersonalityTestBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.startTestButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Replace "https://example.com" with the URL you want to open
                String url = "https://www.indeed.com/career-advice/finding-a-job/jobs-for-myers-briggs-personality-type";
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }

        });
    }

    // Method to handle button click
    public void startTestButtonClick(View view) {
        // Replace "https://example.com" with the URL you want to open
        String url = "https://www.16personalities.com/free-personality-test";
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }


}
