package com.example.careerguidanceapp_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.example.careerguidanceapp_1.databinding.ActivityCategoryBinding;

public class Category extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

                    // Handle item 2 selection
                }
                // Add more conditions as needed for other items

            }





