package com.example.careerguidanceapp_1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class job extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        CardView webDevCardView = findViewById(R.id.webDevCardView);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        CardView appDevCardView = findViewById(R.id.appDevCardView);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        CardView caInternshipCardView = findViewById(R.id.caInternshipCardView);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        CardView teachingInternshipCardView = findViewById(R.id.teachingInternshipCardView);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        CardView pharmacyInternCardView = findViewById(R.id.pharmacyInternCardView);

        // Set onClickListener for Web Development CardView
        webDevCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink("https://internshala.com/internships/web-development-internship/");
            }
        });

        // Set onClickListener for App Development CardView
        appDevCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink("https://internshala.com/internships/mobile-app-development-internship/");
            }
        });

        // Set onClickListener for CA Internship CardView
        caInternshipCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink("https://in.indeed.com/q-ca-firm-for-internship-jobs.html?mna=&&aceid=&gad_source=1&gclid=Cj0KCQjwk6SwBhDPARIsAJ59Gwe3sLz5AdUMovmbMC9aBYlyDgpHV-26ZXsWro8VCikXEutnSzcdzsUaAs7oEALw_wcB&gclsrc=aw.ds");
            }
        });

        // Set onClickListener for Teaching Internship CardView
        teachingInternshipCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink("https://in.indeed.com/q-teaching-internship-jobs.html");
            }
        });

        // Set onClickListener for Pharmacy Intern CardView
        pharmacyInternCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLink("https://www.naukri.com/pharmacy-internships-jobs");
            }
        });
    }

    private void openLink(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);

    }
}